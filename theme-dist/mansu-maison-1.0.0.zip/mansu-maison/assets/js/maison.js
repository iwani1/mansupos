/* Mansu Maison front-end. Progressive enhancement only: every control below
   has a working link or form underneath it, so the shop works without JS. */
(() => {
  'use strict';
  const M = window.MANSU || {};
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const ajax = (ep) => (M.ajax || '').replace('%%endpoint%%', ep);
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /* ---------- Dialogs ---------- */
  const open = (id) => {
    const d = document.getElementById(id);
    if (!d || typeof d.showModal !== 'function') return false;
    if (!d.open) d.showModal();
    return true;
  };
  document.addEventListener('click', (e) => {
    const opener = e.target.closest('[data-open]');
    if (opener) {
      if (open(opener.dataset.open)) {
        e.preventDefault();
        if (opener.dataset.open === 'searchD') setTimeout(() => $('#q') && $('#q').focus(), 30);
      }
      return;
    }
    const closer = e.target.closest('[data-close]');
    if (closer) { const d = closer.closest('dialog'); d && d.close(); }
  });
  $$('dialog').forEach((d) => d.addEventListener('click', (e) => { if (e.target === d) d.close(); }));

  /* ---------- Occasions mega menu ---------- */
  const mb = $('.mega-btn'), mg = $('#mega');
  if (mb && mg) {
    const set = (on) => { mg.hidden = !on; mb.setAttribute('aria-expanded', String(on)); };
    mb.addEventListener('click', () => set(mg.hidden));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !mg.hidden) { set(false); mb.focus(); } });
    document.addEventListener('click', (e) => { if (!e.target.closest('.main-nav')) set(false); });
  }

  /* ---------- Toast ---------- */
  const toastEl = $('#toast');
  let tt;
  const toast = (msg) => {
    if (!toastEl) return;
    $('.toast-t', toastEl).textContent = msg;
    toastEl.classList.add('on');
    clearTimeout(tt);
    tt = setTimeout(() => toastEl.classList.remove('on'), 3500);
  };

  /* ---------- Predictive search ---------- */
  const q = $('#q');
  if (q && M.ajax) {
    const info = $('#searchD .s-info'), cats = $('#searchD .s-cats'), sugg = $('#searchD .sugg');
    let timer, ctrl;
    const run = () => {
      const v = q.value.trim();
      if (v.length < 2) { info.textContent = ''; cats.innerHTML = ''; sugg.innerHTML = ''; return; }
      if (ctrl) ctrl.abort();
      ctrl = new AbortController();
      fetch(ajax('mansu_search') + '&q=' + encodeURIComponent(v), { signal: ctrl.signal, credentials: 'same-origin' })
        .then((r) => r.json())
        .then((d) => {
          const all = M.search + '?s=' + encodeURIComponent(v) + '&post_type=product';
          info.innerHTML = d.total
            ? `${esc((d.total === 1 ? M.i18n.result : M.i18n.results).replace('%d', d.total))} · <a class="link-u" href="${esc(all)}">${esc(M.i18n.seeAll)}</a>`
            : esc(M.i18n.none.replace('%s', v));
          cats.innerHTML = d.cats.map((c) => `<a class="pill" href="${esc(c.url)}">${esc(c.name)}</a>`).join('');
          sugg.innerHTML = d.products.map((p) => `<a href="${esc(p.url)}" data-qv="${p.id}"><img src="${esc(p.img)}" alt="" width="240" height="320" loading="lazy"><span>${esc(p.name)}</span><small>${esc(p.price)}</small></a>`).join('');
        })
        .catch(() => {});
    };
    q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 180); });
    $$('#searchD [data-pop]').forEach((b) => b.addEventListener('click', () => { q.value = b.dataset.pop; run(); q.focus(); }));
    document.addEventListener('keydown', (e) => {
      if (e.key === '/' && !/input|textarea|select/i.test(document.activeElement.tagName) && !$('dialog[open]')) { e.preventDefault(); open('searchD'); q.focus(); }
    });
  }

  /* ---------- Quick view ---------- */
  const qv = $('#qvD');
  const body = qv && $('.qv-body', qv);
  const initForm = (root) => {
    const jq = window.jQuery;
    if (!jq) return;
    jq(root).find('.variations_form').each(function () {
      if (typeof jq.fn.wc_variation_form === 'function') jq(this).wc_variation_form();
      jq(this).trigger('check_variations');
    });
    jq(document.body).trigger('mansu_quick_view_loaded', [root]);
  };
  const showQuickView = (id, fallbackUrl) => {
    if (!qv || !M.ajax) { if (fallbackUrl) location.href = fallbackUrl; return; }
    body.innerHTML = `<p class="qv-loading">${esc(M.i18n.loading)}</p>`;
    $$('dialog[open]').forEach((d) => d !== qv && d.close());
    open('qvD');
    fetch(ajax('mansu_quick_view') + '&id=' + encodeURIComponent(id), { credentials: 'same-origin' })
      .then((r) => r.json())
      .then((d) => {
        if (!d.success) throw new Error('qv');
        body.innerHTML = d.data.html;
        initForm(body);
        const first = $('select, input[type=radio], button[type=submit]', body);
        if (first) first.focus();
      })
      .catch(() => { if (fallbackUrl) location.href = fallbackUrl; else qv.close(); });
  };
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-qv]');
    if (!t) return;
    e.preventDefault();
    showQuickView(t.dataset.qv, t.getAttribute('href') || '');
  });

  /* Add to cart from quick view, keeping the shopper on the page. */
  if (qv) {
    qv.addEventListener('submit', (e) => {
      const form = e.target.closest('form.cart');
      if (!form || !M.ajax) return;
      e.preventDefault();
      const msg = $('.qv-msg', qv);
      const btn = $('button[type=submit]', form);
      const vid = $('input[name=variation_id]', form);
      if (vid && !Number(vid.value)) { if (msg) msg.textContent = M.i18n.choose; return; }
      const data = new FormData(form);
      const pid = form.querySelector('[name=add-to-cart]');
      if (!data.get('product_id') && pid) data.set('product_id', pid.value);
      data.delete('add-to-cart');
      if (btn) { btn.disabled = true; btn.classList.add('loading'); }
      fetch(ajax('mansu_add_to_cart'), { method: 'POST', body: data, credentials: 'same-origin' })
        .then((r) => r.json())
        .then((res) => {
          if (res.error) { if (msg) msg.textContent = res.message || M.i18n.error; return; }
          if (window.jQuery) window.jQuery(document.body).trigger('added_to_cart', [res.fragments, res.cart_hash, window.jQuery(btn)]);
          else applyFragments(res.fragments);
          qv.close();
          toast(M.i18n.added);
        })
        .catch(() => { if (msg) msg.textContent = M.i18n.error; })
        .finally(() => { if (btn) { btn.disabled = false; btn.classList.remove('loading'); } });
    });
  }
  const applyFragments = (frags) => {
    Object.keys(frags || {}).forEach((sel) => $$(sel).forEach((el) => { el.outerHTML = frags[sel]; }));
  };

  /* Any AJAX add to cart on the site (including WooCommerce's own buttons) confirms with a toast. */
  if (window.jQuery) {
    window.jQuery(document.body).on('added_to_cart', (_e, _f, _h, $btn) => {
      if (!$btn || !$btn.closest || !$btn.closest('#qvD').length) toast(M.i18n.added);
    });
  }

  /* ---------- Filter drawer: send tidy URLs (comma lists, no empty fields) ---------- */
  const ff = $('#filterForm');
  if (ff) {
    ff.addEventListener('submit', (e) => {
      e.preventDefault();
      const params = new URLSearchParams();
      const groups = {};
      new FormData(ff).forEach((v, k) => {
        if (v === '') return;
        if (k.endsWith('[]')) (groups[k.slice(0, -2)] = groups[k.slice(0, -2)] || []).push(v);
        else params.set(k, v);
      });
      Object.keys(groups).forEach((k) => params.set(k, groups[k].join(',')));
      if (!groups.filter_size) params.delete('query_type_size');
      if (!groups.filter_color) params.delete('query_type_color');
      const qs = params.toString();
      location.href = ff.action + (qs ? (ff.action.includes('?') ? '&' : '?') + qs : '');
    });
  }

  /* ---------- Sticky toolbar offset follows the real header height ---------- */
  const hdr = $('.site-header');
  if (hdr && 'ResizeObserver' in window) {
    new ResizeObserver(() => document.documentElement.style.setProperty('--hdr', hdr.offsetHeight + 'px')).observe(hdr);
  }

  /* Smooth in-page scrolling only when motion is welcome. */
  if (!reduce) document.documentElement.style.scrollBehavior = 'smooth';
})();
